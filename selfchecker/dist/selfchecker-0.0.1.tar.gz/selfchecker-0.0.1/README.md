this is made to used to my bot

ok?
